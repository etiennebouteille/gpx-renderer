# Important!

GPX import to Blender is now a part of the blender-osm addon. Get it for free at https://gumroad.com/l/blender-osm. The source code is located [here](https://github.com/vvoovv/blender-osm/tree/release).

# blender-gpx
Importer of GPS track files (.gpx) for Blender

* [Documentation](https://github.com/vvoovv/blender-gpx/wiki/Documentation)
* twitter: [@prokitektura](https://twitter.com/prokitektura)

## Donations
If you find the addons useful, please consider making a donation:

[![Please donate](https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=NNQBWQ6TH2N7N)
